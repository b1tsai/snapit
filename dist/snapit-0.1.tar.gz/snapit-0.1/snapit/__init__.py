from markdown import markdown

def talk():
    return markdown("Hello World!")