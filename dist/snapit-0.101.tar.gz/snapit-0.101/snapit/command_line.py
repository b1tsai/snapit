from . import talk

def main():
    print talk()