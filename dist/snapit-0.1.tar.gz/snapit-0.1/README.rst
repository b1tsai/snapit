SNAP-IT
-------

To use, simply::

    >>> import snapit
    >>> print snapit.test()